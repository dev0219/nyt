const detectMachine = [
    { Machine: 'Card-S1-01', JoibId: 'J202076589'},
    { Machine: 'Card-S1-02', JoibId: 'J202037483'},
    { Machine: 'Card-S1-03', JoibId: 'J202073954'},
  ]
  
  export default detectMachine