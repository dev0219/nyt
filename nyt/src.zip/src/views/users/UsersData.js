const usersData = [
  { Machine: 'Card-S1-01', Target: '800', Actual: '200', EFF: '75%', NP: 'N', _classes: 'table-success'},
  { Machine: 'Card-S1-02', Target: '800', Actual: '200', EFF: '75%', NP: 'Y', _classes: 'table-warning'},
  { Machine: 'Card-S1-03', Target: '800', Actual: '200', EFF: '75%', NP: 'N', _classes: 'table-danger'},
  { Machine: 'Card-S1-04', Target: '800', Actual: '200', EFF: '75%', NP: 'Y', _classes: 'table-danger'},
  { Machine: 'Card-S1-05', Target: '800', Actual: '200', EFF: '75%', NP: 'N', _classes: 'table-success'},
  { Machine: 'Card-S1-06', Target: '800', Actual: '200', EFF: '75%', NP: 'Y', _classes: 'table-warning'},
  { Machine: 'Card-S1-07', Target: '800', Actual: '200', EFF: '75%', NP: 'N', _classes: 'table-danger'},
  { Machine: 'Card-S1-08', Target: '800', Actual: '200', EFF: '75%', NP: 'Y', _classes: 'table-success'},
  { Machine: 'Card-S1-09', Target: '800', Actual: '200', EFF: '75%', NP: 'Y', _classes: 'table-success'},
  { Machine: 'Card-S1-10', Target: '800', Actual: '200', EFF: '75%', NP: 'N', _classes: 'table-danger'},
  { Machine: 'Card-S1-11', Target: '800', Actual: '200', EFF: '75%', NP: 'N', _classes: 'table-danger'},
]

export default usersData


