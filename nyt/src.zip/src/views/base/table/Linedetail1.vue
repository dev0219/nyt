<template>
  <CCard>
    <CCardHeader>
      <slot name="header">
        Detail
      </slot>
    </CCardHeader>
    <CCardBody>
      <CDataTable
        hover
        :striped="striped"
        :bordered="bordered"
        :small="small"
        :fixed="fixed"
        :items="items"
        items-per-page-select
        :fields="fields"
        :items-per-page="10"
        :dark="dark"
        pagination
        border
        style="text-align:center"
        sorter   
      >
      </CDataTable>
    </CCardBody>
  </CCard>
</template>

<script>
export default {
  name: 'Table',
  props: {
    items: Array,
    fields: {
      type: Array,
      default () {
        return ['machine_id','realtime_target', 'Actual', 'EFF', 'NP']
      }
    },
    caption: {
      type: String,
      default: 'Table'
    },
    sorter: Boolean,
    hover: Boolean,
    striped: Boolean,
    bordered: Boolean,
    small: Boolean,
    fixed: Boolean,
    dark: Boolean
  },
  methods: {
    getBadge (status) {
      return status === 'Active' ? 'success'
        : status === 'Inactive' ? 'secondary'
          : status === 'Pending' ? 'warning'
            : status === 'Banned' ? 'danger' : 'primary'
    }
  }
}
</script>
